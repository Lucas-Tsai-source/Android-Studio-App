package com.example.thuuuuuu;

import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.*;
import android.widget.BaseAdapter;
import android.widget.*;
import android.widget.TextView;
import android.graphics.*;
import java.util.*;
import java.io.*;
import java.util.*;
import java.text.*;

public class MyGoodAdapter extends BaseAdapter {

    private LayoutInflater myInflater;
    Vector<String> pGoods = null; // ����ListView�n�q�X���ɮ׸�T

    public MyGoodAdapter(Context ctxt, Vector<String> goods){
        myInflater = LayoutInflater.from(ctxt);
        this.pGoods = goods;
    }

    @Override
    public int getCount() {
        return pGoods.size();
    }

    @Override
    public Object getItem(int position)
    {
        String arr[] = pGoods.get(position).split("-");
        return arr[1];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewTag viewtag = null;

        //���olistItem�e�� view
        convertView = myInflater.inflate(R.layout.listview_item, null);
        //�غclistItem���eview
        viewtag = new ViewTag(
                (CheckBox)convertView.findViewById(R.id.checkBox1),
                (ImageView)convertView.findViewById(R.id.icon),
                (TextView) convertView.findViewById(R.id.filename),
                (TextView) convertView.findViewById(R.id.fileinfo)
        );
        int images[] = {R.drawable.good1,R.drawable.good2,R.drawable.good3,R.drawable.good4,R.drawable.good5,R.drawable.good6,R.drawable.good7,R.drawable.good8};
        String arr[] = pGoods.elementAt(position).split("-");
        viewtag.icon.setImageResource(images[position]);
        viewtag.goodname.setText(arr[1]);
        viewtag.goodinfo.setText("單價是"+arr[2]+"數量是"+arr[4]);
        convertView.setTag(viewtag);

        return convertView;
    }

    //�ۭq���O�A��F�ӧOlistItem����view���󶰦X�C
    class ViewTag
    {
        CheckBox Selected;
        ImageView icon;
        TextView goodname;
        TextView goodinfo;

        public ViewTag(CheckBox selected, ImageView icon, TextView title, TextView info)
        {
            this.Selected = selected;
            this.Selected.setVisibility(View.GONE);
            this.icon = icon;
            this.goodname = title;
            this.goodinfo = info;
        }
    }
}
