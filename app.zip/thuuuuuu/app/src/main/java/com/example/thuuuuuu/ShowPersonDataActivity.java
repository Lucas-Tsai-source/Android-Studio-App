package com.example.thuuuuuu;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.*;
import java.util.*;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.*;


import java.util.Vector;


public class ShowPersonDataActivity extends AppCompatActivity {

    Button btnRestore = null;
    Button btnSave = null;
    Button btnCart =null;

    EditText etName =null;
    EditText etcard =null;
    EditText etphone =null;
    EditText etemail =null;
    EditText etaddress =null;
    EditText etData =null;
    EditText etCar =null;
    EditText etage =null;
    Vector<String> pGoodString = null;
    public static String sMyData = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.setTitle("個人資料");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_person_data);

        etName = (EditText) findViewById(R.id.editText1);
        etcard = (EditText) findViewById(R.id.editText2);
        etphone= (EditText) findViewById(R.id.editTextPhone);
        etemail = (EditText) findViewById(R.id.editText4);
        etaddress = (EditText) findViewById(R.id.editText5);
        etData = (EditText) findViewById(R.id.editText6);
        etCar = (EditText) findViewById(R.id.editText7);
        etage = (EditText) findViewById(R.id.editText10);
        pGoodString = new Vector<String>();
        btnRestore = (Button) findViewById(R.id.button2);
        btnRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               restore();
            }
        });

        btnSave = (Button) findViewById(R.id.button3);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save();
                etData.setText("個人資料:\n"
                               +"姓名："+etName.getText().toString()+"\n"
                              +"年紀："+etage.getText().toString()+"\n"
                              +"信用卡："+etcard.getText().toString()+"\n"
                              +"電話："+etphone.getText().toString()+"\n"
                              +"email："+etemail.getText().toString()+"\n"
                              +"地址："+etaddress.getText().toString());
                etCar.setText(ShowGoodInfoActivity.sMyCart);
                sMyData = etData.getText().toString();
            }
        });
        restore();

        btnCart = (Button) findViewById(R.id.button4);
        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShowPersonDataActivity.this, ShowCardInfoActivity.class);
                startActivity(intent);
            }
        });
    }

    public void restore()
    {
        String name = getSharedPreferences("MyData", MODE_PRIVATE)
                .getString("Name", "");
        etName.setText(name);

        String age = getSharedPreferences("MyData", MODE_PRIVATE)
                .getString("age", "");
        etage.setText(age);

        String card = getSharedPreferences("MyData", MODE_PRIVATE)
                .getString("card", "");
        etcard.setText(card);

        String phone = getSharedPreferences("MyData", MODE_PRIVATE)
                .getString("phone", "");
        etphone.setText(phone);

        String email = getSharedPreferences("MyData", MODE_PRIVATE)
                .getString("email", "");
        etemail.setText(email);

        String address = getSharedPreferences("MyData", MODE_PRIVATE)
                .getString("address", "");
        etaddress.setText(address);
    }
    public void save()
    {
        SharedPreferences pref = getSharedPreferences("MyData", MODE_PRIVATE);
        pref.edit()
                .putString("Name",etName.getText().toString())
                .putString("age",etage.getText().toString())
                .putString("card",etcard.getText().toString())
                .putString("phone",etphone.getText().toString())
                .putString("email",etemail.getText().toString())
                .putString("address",etaddress.getText().toString())
                .commit();
    }
}