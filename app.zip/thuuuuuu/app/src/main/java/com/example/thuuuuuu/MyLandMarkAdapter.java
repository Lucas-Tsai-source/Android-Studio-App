package com.example.thuuuuuu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Vector;


public class MyLandMarkAdapter extends BaseAdapter  {

    private LayoutInflater myInflater;
    Vector<String> pLandMarks = null; // ����ListView�n�q�X���ɮ׸�T

    public MyLandMarkAdapter(Context ctxt, Vector<String> landmarks){
        myInflater = LayoutInflater.from(ctxt);
        this.pLandMarks = landmarks;
    }

    @Override
    public int getCount() {
        return pLandMarks.size();
    }

    @Override
    public Object getItem(int position)
    {
        String arr[] = pLandMarks.get(position).split("-");
        return arr[0];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override//如何顯示資料
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewTag viewtag = null;

        //���olistItem�e�� view
        convertView = myInflater.inflate(R.layout.listview_item, null);
        //�غclistItem���eview
        viewtag = new ViewTag(
                (CheckBox)convertView.findViewById(R.id.checkBox1),
                (ImageView)convertView.findViewById(R.id.icon),
                (TextView) convertView.findViewById(R.id.filename),
                (TextView) convertView.findViewById(R.id.fileinfo)
        );
        int images[] = {R.drawable.land1,R.drawable.land2,R.drawable.land3,R.drawable.land4,R.drawable.land5,R.drawable.land6,R.drawable.land7,R.drawable.land8};
        String arr[] = pLandMarks.elementAt(position).split("-");
        if(arr[8].compareTo("true")==0)
            viewtag.Selected.setChecked(true);
        else
            viewtag.Selected.setChecked(false);
        viewtag.icon.setImageResource(images[position]);
        viewtag.landmarkname.setText(arr[0]);
        viewtag.landmarkinfo.setText("緯度:"+arr[1]+"電話:"+arr[4]);
        convertView.setTag(viewtag);

        return convertView;
    }

    //�ۭq���O�A��F�ӧOlistItem����view���󶰦X�C
    class ViewTag
    {
        CheckBox Selected;
        ImageView icon;
        TextView landmarkname;
        TextView landmarkinfo;

        public ViewTag(CheckBox selected, ImageView icon, TextView title, TextView info)
        {
            this.Selected = selected;
            this.Selected.setVisibility(View.VISIBLE);
            this.Selected.setEnabled(false);
            this.icon = icon;
            this.landmarkname = title;
            this.landmarkinfo = info;
        }
    }
}

