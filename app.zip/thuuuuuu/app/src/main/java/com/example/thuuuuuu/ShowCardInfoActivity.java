package com.example.thuuuuuu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

public class ShowCardInfoActivity extends AppCompatActivity {

    Button btnCart = null;
    Button btnCode = null;
    Button btnEmail = null;
    WebView wvView = null;
    EditText etContent = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.setTitle("購物車資訊");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_card_info);

        etContent = (EditText) findViewById(R.id.editText1);
        wvView = (WebView) findViewById(R.id.webView1);
        btnCart = (Button) findViewById(R.id.button1);
        btnCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                wvView.setVisibility(View.GONE);
                etContent.setVisibility(View.VISIBLE);
                etContent.setText(ShowPersonDataActivity.sMyData+"\n"+ShowGoodInfoActivity.sMyCart);
            }
        });
        btnCode = (Button) findViewById(R.id.button2);
        btnCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etContent.setVisibility(View.GONE);
                wvView.setVisibility(View.VISIBLE);
                wvView.loadUrl("https://zxing.org/w/chart?cht=qr&chs=350x350&chld=L&choe=UTF-8&chl="+ShowPersonDataActivity.sMyData+"\n"+ShowGoodInfoActivity.sMyCart);
            }
        });
        btnEmail = (Button) findViewById(R.id.button11);
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(ShowCardInfoActivity.this, EmailActivity.class);
                startActivity(intent);
            }
        });
    }
}