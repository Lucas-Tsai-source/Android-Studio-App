package com.example.thuuuuuu;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;

// GPS資訊提供者，可以以背景服務的形式提供GPS的相關訊息
// 注意這是以背景服務形式運作的java檔案，不是App的Activity頁面
// LocationListener是當特定條件發生時，可以觸發GPSProvider的某些功能，如onLocationChanged
public class GPSProdiver extends Service implements LocationListener {
    private Context mContext = null; // 呼叫此java檔的App的Activity頁面
    public static boolean isGPSEnabled = false; // 是否可以從衛星取得GPS資訊
    public static boolean isNetworkEnabled = false; // 是否可以從Wi-Fi取得GPS資訊
    boolean canGetLocation = false; // 能否得到現在的GPS位置
    public static Location pLocation; // 現在的位置
    double latitude, longitude; // 緯度、精度

    // 移動10公尺就更新GPS位置
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10; // 10 meters
    // 每隔60秒就更新GPS位置
    private static final long MIN_TIME_BW_UPDATES = 1000 * 30 * 1; // 以毫米計算，一秒=1000毫秒

    protected LocationManager locationManager;

    public GPSProdiver(Context context) {
        this.mContext = context;
        getLocation();
    }
    // 取得目前的GPS位置
    public Location getLocation()
    {
        try
        {
            // 取得GPS裝置
            locationManager = (LocationManager) mContext.getSystemService(this.mContext.LOCATION_SERVICE);
            // 是否能從GPS衛星取得GPS資訊
            isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            // 是否能從Wi-Fi無線網路取得GPS資訊
            isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            // 判斷在AndroidManifest.xml是否有設定可以存取GPS的權限
            if (ActivityCompat.checkSelfPermission(this.mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            {// 如果沒有設定權限，在此強制取得權限
                ActivityCompat.requestPermissions((DirectGPSActivity)mContext, new String[]{
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                }, 10);
            }

            if (!isGPSEnabled && !isNetworkEnabled)
            {   // 無法透過衛星或Wi-Fi取的GPS，亦即GPS沒啟動，發出警告訊號
                showSettingsAlert();
            }
            else
            { // 能取得GPS資訊
                this.canGetLocation = true;
                if (isGPSEnabled)
                {// 可以透過衛星取得GPS資訊，並取得目前位置的GPS
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    pLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                }
                if (isNetworkEnabled)
                {// 可以透過衛星取得GPS資訊，並取得目前位置的GPS
                    // 注意，衛星取得的GPS資訊的精細度比用Wi-Fi來的高
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    pLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
                if (pLocation != null)
                {// 若成功取得目前位置的GPS，設定緯度和經度
                    latitude = pLocation.getLatitude();
                    longitude = pLocation.getLongitude();
                    return pLocation;
                }
                else
                {// 沒有取得GPS資續，緯度和精度都設為0
                    latitude = 0;
                    longitude = 0;
                    return (pLocation = null);
                }


            }

        } catch (Exception e)
        {// 發出錯誤的警告訊號
            e.printStackTrace();
            // 因為這不是Activity也面的程式，所以不能用Toast.makeText來發出警告訊息
        }

        return (pLocation = null);
    }

    public void stopUsingGPS()
    {// 中止GPS資訊的存取
        if (locationManager != null) {
            locationManager.removeUpdates(GPSProdiver.this);
        }
    }

    public double getLatitude()
    {// 取得緯度
        if (pLocation != null) {
            latitude = pLocation.getLatitude();
        }

        return latitude;
    }

    public double getLongitude()
    {// 取得經度
        if (pLocation != null) {
            longitude = pLocation.getLongitude();
        }

        return longitude;
    }

    public boolean canGetLocation()
    {// 若是true，可以取得GPS資訊
        return this.canGetLocation;
    }

    // 無法存取GPS資訊。出現警示對話盒，按yes，讓你設定GPS的開啟
    public void showSettingsAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);

        alertDialog.setTitle("GPS設定");
        alertDialog
                .setMessage("GPS沒有啟動. 你要去設定GPS的開啟方式？");
        alertDialog.setPositiveButton("GPS設定",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(
                                Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        mContext.startActivity(intent);
                    }
                });

        alertDialog.setNegativeButton("取消",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();
    }

    @Override
    public void onLocationChanged(Location location)
    {// 這個功能非常重要，當移動超過一定距離(上面設定是10公尺)，就更新GPS資訊
        getLocation();
        if (location != null) {
            pLocation = location;
            longitude = location.getLongitude();
            latitude = location.getLatitude();
            // 下面這行是關鍵。當GPS資訊更新時，通知某也面更新某Activity的畫面資訊
            ((DirectGPSActivity)mContext).notifyLocationChanged(location.getLatitude(),location.getLongitude());
        }
    }

    @Override
    public void onProviderDisabled(String provider) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

}