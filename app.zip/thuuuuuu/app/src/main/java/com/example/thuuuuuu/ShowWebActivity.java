package com.example.thuuuuuu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ShowWebActivity extends AppCompatActivity {
    WebView pweb = null;
    Button btnCallPhone = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_web);

        pweb = (WebView) findViewById(R.id.webView1);
        pweb.loadUrl("https://www.thu.edu.tw");

        btnCallPhone = (Button) findViewById(R.id.button);
        btnCallPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                //startActivity(intent);

                Intent intent = new Intent(ShowWebActivity.this, CallPhone.class);
                startActivity(intent);
            }
        });

    }
}