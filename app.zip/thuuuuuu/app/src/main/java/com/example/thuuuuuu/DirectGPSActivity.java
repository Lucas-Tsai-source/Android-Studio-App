package com.example.thuuuuuu;

import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Vector;

public class DirectGPSActivity extends AppCompatActivity {
    WebView pWeb = null;
    Spinner spinner = null;
    Vector<String> pList = null;
    TextView tvGPSInfo = null;//秀出緯度和經度
    Location pLocation = null;//目前的位置
    Button btnGPS = null;
    GPSProdiver pGPS = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_gpsactivity);
        this.setTitle("導航");//頁面的標題

        pGPS = new GPSProdiver(DirectGPSActivity.this);
        //將landmark的景點名稱移到List，以便顯示在Spinner
        pList = new Vector<String>();
        for (int i = 0; i < ListLandMarkActivity.pLandMark.size(); i++) {//字串分解，將名稱(arr[0])移到Spinner
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(i).split("-");
            pList.add(arr[0]);
        }
        //設定元件變數和XML元件的連結
        tvGPSInfo = (TextView) findViewById(R.id.textView1);
        pWeb = (WebView) findViewById(R.id.webView1);
        pWeb.setWebViewClient(new WebViewClient());

        //設定Spinner的相關步驟
        spinner = findViewById(R.id.spinner1);
        ArrayAdapter adapter = new ArrayAdapter(this
                , android.R.layout.simple_dropdown_item_1line, pList);//Plist放所有景點的名稱
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(DirectGPSActivity.this, "你選取的是" + spinner.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
                //選一個景點，帶出景點的GPS資訊，並進行導航
                //directWeb();//會被自動執行
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)//這個不可少
            {
            }
        });
        //進入此頁面會自動擷取GPS資訊，但若是GPS的啟動過慢，你就要退出此頁面再進入此頁面
        //這樣很麻煩，因此設一個Button用來擷取GPS的資訊，就不用進進出出此頁面
        btnGPS = (Button) findViewById(R.id.button1);
        btnGPS.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //選一個景點，貸出景點的GPS資訊並進行導航
                    directWeb();
                }
            });
        }
        public void notifyLocationChanged(Double lat, Double lng)
        {
            pLocation = GPSProdiver.pLocation;
            showLocation();
        }
        public void showLocation()
        {//依據是否取到目前位置的資訊，決定顯示哪種訊息
            if (pLocation != null)
            {
                tvGPSInfo.setText("GPS來源：" + GPSProdiver.isGPSEnabled + ",Network來源：" + GPSProdiver.isNetworkEnabled + "\n"
                        + pLocation.getLatitude() + "， "+pLocation.getLongitude());
            } else
                tvGPSInfo.setText("沒有提到GPS位置");
        }
        public void directWeb()
        {
            //webview的相關設定
            WebSettings websettings = pWeb.getSettings();
            //有些網頁需要開啟javascript才能正常顯示
            websettings.setJavaScriptEnabled(true);//開啟支援javascript的功能
            websettings.setJavaScriptCanOpenWindowsAutomatically(true);//自動啟動javascript
            //websettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            //websettings.setSupporyZoom(true);//支持屏幕縮放
            String url = "";
            //先得到選定的spinner選項的index，用listLandMarkActivity.pLandMark得到第index個景點的資料，字串分解，得到arr[1](景點GPS座標)
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(spinner.getSelectedItemPosition()).split("-");
            if (pLocation != null)
            {//如果目前位置是已知，就從目前位置規劃一條路徑到你選的景點(spinner的選項)
                url = "https://maps.google.com/maps?saddr=" + pLocation.getLatitude() + "," + pLocation.getLongitude() + "&daddr=" + arr[1];
            }
            else
            {//如果沒有找到目前位置，就用一特定出發座標(自己改)，規劃路線到你想去的地方(spinner的選項)
                url = "https://maps.google.com/maps?saddr=25.033408,121.564099&daddr=" + arr[1];
            }
            //用webview顯示Google Map的導航路線
            //目前webview無法顯示導航路線的網址，原因待查
            pWeb.loadUrl(url);
            //因為webview無法顯示導航路線的網址，所以呼叫Google Map App顯示導航路線
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        }
}