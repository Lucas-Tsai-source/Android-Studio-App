package com.example.thuuuuuu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Vector;

public class ListLandMarkwithImageActivity extends AppCompatActivity {
    ListView listview = null;
    public static Vector<String> pLandMarks = null;
    Vector<String> pList = null;
    Button btnSearch = null;
    EditText etKeyword=null;
    MyLandMarkAdapter adapter=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_land_markwith_image);

        this.setTitle("景點清單");


        pLandMarks = new Vector<String>();
        pList = new Vector<String>();
        pLandMarks = ListLandMarkActivity.pLandMark;

        btnSearch=(Button) findViewById(R.id.button1);
        etKeyword=(EditText) findViewById(R.id.editText1);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLandMark(etKeyword.getText().toString());
            }
        });

        listview = (ListView) findViewById(R.id.listView1);
        //ListView 要顯示的內容
        //String[] str = {"滿天星","紫藤花","桃花","百合花","薰衣草","山茶花","櫻花","向日葵"};
        //android.R.layout.simple_list_item_1 為內建樣式，還有其他樣式可自行研究
        adapter = new MyLandMarkAdapter(this, pList);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListLandMarkwithImageActivity.this, ShowLandMarkInfoActivity.class);
                intent.putExtra("LandMark",(String)adapter.getItem(position));
                startActivity(intent);
            }
        });
        showLandMark("");

    }
    public void showLandMark(String keyword)
    {
        pList.clear();
        for(int i=0;i< pLandMarks.size();i++)
        {
            String str =pLandMarks.elementAt(i);
            String arr[]= str.split("-");
            if (arr[0].indexOf(keyword)!=-1)
                pList.add(str);
        }
        adapter.notifyDataSetChanged();

    }
    protected void onResume()
    {
        super.onResume();
        //adapter.notifyDataSetChanged();
        showLandMark(etKeyword.getText().toString());
    }
}