package com.example.thuuuuuu;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.Vector;
//這個頁面會擷取GPS資訊，做出導航路線規劃，缺點是GPS資訊要手動更新
public class DirectLandMarkActivity extends AppCompatActivity {
    WebView pWeb = null;
    Spinner spinner = null;
    Vector<String> pList = null;
    public LocationManager mLocationManager = null;
    //public int LOCATION_UPDATE_MIN_DISTANCE = 10;//每隔10公尺更新GPS資訊
    //public int LOCATION_UPDATE_MIN_TIME = 50;//每隔50秒更新GPS資訊
    TextView tvGPSInfo = null;//顯示緯度和經度
    Location pLocation = null;//目前的位置
    Button btnGPS = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direct_land_mark);
        this.setTitle("導航");//頁面的標題
        //將LandMark的景點名稱移到List，以便顯示在Spinner
        pList = new Vector<String>();
        for (int i = 0; i < ListLandMarkActivity.pLandMark.size(); i++) {//字串分解，將名稱(arr[0])移到spinner
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(i).split("-");
            pList.add(arr[0]);
        }
        //設定元件變數和XML元件的連結
        tvGPSInfo = (TextView) findViewById(R.id.textView1);
        pWeb = (WebView) findViewById(R.id.webView1);
        pWeb.setWebViewClient(new WebViewClient());
        //spinner的設定相關步驟
        spinner = findViewById(R.id.spinner1);
        ArrayAdapter adapter = new ArrayAdapter(this
                , android.R.layout.simple_dropdown_item_1line, pList);//pList放所有景點的名稱
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(DirectLandMarkActivity.this, "你選取的是" + spinner.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
                //選一個景點，帶出景點的GPS資訊並進行導航
                getGPSandDirectWeb();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }//這個不可少
        });
        //進入此頁面會自動擷取GPS資訊，但若是GPS的啟動過慢，你就要退出此頁面在進入此頁面
        //這樣很麻煩，因此設一個Button，用來擷取GPS的資訊，就不用進進出出此頁面了
        btnGPS = (Button) findViewById(R.id.button1);
        btnGPS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //選一個景點，帶出景點的GPS資訊並進行導航
                getGPSandDirectWeb();
            }
        });
        //自動執行，選一個景點，戴出景點的GPS資訊並進行導航
        getGPSandDirectWeb();
    }
    //找到選定景點的GPS資訊和規劃導航的路線
    public void getGPSandDirectWeb ()
    {
        pLocation = openGPS();//取得現在位址的的GPS
        showLocation();//在TextView顯示經緯度
        directWeb();//在WebView顯示導航路線
    }
    //要手動開啟GPS服務，然後城市會帶出GPS管理者，進一步取得GPS資料
    public Location openGPS()
    {
        //取得GPS管理者
        mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        //設定GPS每隔多遠或每隔多久就更新一次，因為要設LocationListener，城市複雜，所以略過
        //mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, LOCATION, LOCATION_UPDATE_MIN_TIME * 1000)

        //設定GPS的相關參數
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(false);//設置允許產生資費
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        //GPS資訊來源有衛星和Wi-Fi，這裡決定用哪種來源
        String provider = mLocationManager.getBestProvider(criteria, false);
        try
        {//使用GPS是要用全縣，傳統是在AndriodMainfest.xml設定所有頁面的權限，新的方式是要在每個頁面各自設定
            if (ActivityCompat.checkSelfPermission(DirectLandMarkActivity.this , Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            //&& ActivityCompat.checkSelPermission(this, Mainfest.permission.ACCESS_COARSE_LOCATION) != PackageManger
            {//網路上說要取得Mainfest.permission.ACCESS_FINE_LOCATIOSS_COAN和Mainfest.permission.ACCERSE_LOCATION兩個
                //但是只要取得Mainfest.permission.ACCESS_FINE_LOCATION(衛星GPS資訊)的權限就可以了
                //Mainfest.permission.ACCESS_COARSE_LOCATION(Wi-Fi資訊)的精準度較差，可以不用取得權限
                ActivityCompat.requestPermissions((DirectLandMarkActivity) this, new String[]{
                        android.Manifest.permission.ACCESS_FINE_LOCATION}, 10);
            }
        }
        catch (Exception e)
        {//有意外狀況，發出警告訊號
            Toast.makeText(DirectLandMarkActivity.this, "Error：" + e.toString(), Toast.LENGTH_LONG).show();
        }
        //傳回目前位置的資訊
        return mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    }
    public void showLocation ()
    {//依據是否取到目前位置的資訊，決定顯示哪一種訊息
        if(pLocation != null)
        {
            tvGPSInfo.setText("緯度：" + pLocation.getLatitude() + "經度：" + pLocation.getLongitude());
        }
        else
            tvGPSInfo.setText("沒有提到GPS位置。");
    }
    public void directWeb()
    {
        //WebView的相關設定
        WebSettings websettings = pWeb.getSettings();
        //有些網頁要開啟javascript才能正常顯示
        websettings.setJavaScriptEnabled(true);//開啟支援javascript的功能
        websettings.setJavaScriptCanOpenWindowsAutomatically(true);//自動啟動javascript
        //websettings.setCacheMode(WebSettings.LOAD_NP_CACHE);
        //websettings.setSupportZoom(true);//支援屏幕縮放
        String url = "";
        //先得到你選定的spinner選項的index，再用ListLandMarkActivity.pLandMark得到第index個景點的資料，字串分解，得到arr[1](景點GPS座標)
        String arr[] = ListLandMarkActivity.pLandMark.elementAt(spinner.getSelectedItemPosition()).split("-");
        if(pLocation != null)
        {//如果目前位置是已知，就從目前位置規劃一條路徑到你選去的景點(spinner的選項)
            url = "https://maps.google.com/maps?saddr="+pLocation.getLatitude()+","+pLocation.getLongitude()+"&daddr="+arr[1];
        }
        else
        {//如果沒有找到目前位置，就用一特定出發座標(自己改)，規劃路線到你想去的景點(spinner的選項)
            url = "https://maps.google.com/maps?saddr=25.033408,121.564099&daddr="+arr[1];
        }
        //用WebView顯示Google Map的導航路線
        //目前WebView無法顯示導航路線的網址，原因待查
        pWeb.loadUrl(url);
        //因為WebView無法顯示導航路線的網址，所以呼叫Google Map App顯示導航路線
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }
}