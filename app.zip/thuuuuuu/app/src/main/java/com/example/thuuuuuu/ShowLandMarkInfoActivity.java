package com.example.thuuuuuu;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class ShowLandMarkInfoActivity extends AppCompatActivity {

    EditText etName = null;
    EditText etLocation = null;
    EditText etAddress = null;
    EditText etPhone = null;
    EditText etOpentime = null;
    EditText etDescription = null;
    EditText etScan = null;
    EditText etWeb = null;
    CheckBox etChe = null;

    EditText etDis = null;
    ImageView ivImage = null;
    Button btnScan = null;
    Button btnInt = null;
    Button btnDirect = null;
    Button btnShop = null;
    Button btnPhone = null;
    Button btnCard = null;

    String sStyle="";
    int iIndex=-1;

    public static String sMyCart = "";

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_land_mark_info);
        this.setTitle("景點資訊");

        etName = (EditText) findViewById(R.id.editText1);
        etLocation = (EditText) findViewById(R.id.editText2);
        etAddress = (EditText) findViewById(R.id.editText3);
        etPhone = (EditText) findViewById(R.id.editText4);
        etOpentime = (EditText) findViewById(R.id.editText5);
        etDescription = (EditText) findViewById(R.id.editText6);
        etScan = (EditText) findViewById(R.id.editText7);
        ivImage = (ImageView) findViewById(R.id.imageView1);
        etWeb = (EditText) findViewById(R.id.editText8);
        etChe = (CheckBox) findViewById(R.id.checkBox);
        String LandMarkName = this.getIntent().getStringExtra("LandMark");
        ShowLandMarkInfo(LandMarkName);

        btnScan = (Button) findViewById(R.id.button1);
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE"); // "PRODUCT_MODE for bar codes
                    startActivityForResult(intent, 0);

                } catch (Exception e) {

                    Uri marketUri = Uri.parse("market://details?id=com.google.zxing.client.android");
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    startActivity(marketIntent);

                }
            }
        });
        btnInt = (Button) findViewById(R.id.button7);
        btnInt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(ShowLandMarkInfoActivity.this, ShowWebActivity.class);
                startActivity(intent);
            }
        });
        btnDirect = (Button) findViewById(R.id.button2);
        btnDirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(ShowLandMarkInfoActivity.this, DirectLandMarkActivity.class);
                intent.putExtra("LandMark",iIndex);
                startActivity(intent);
            }
        });
        btnShop = (Button) findViewById(R.id.button3);
        if(sStyle.compareTo("商店")==0)
        {
            btnShop.setVisibility(View.VISIBLE);
        }
        else
        {
            btnShop.setVisibility(View.GONE);
        }
        btnShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(ShowLandMarkInfoActivity.this, ListGoodswithImageActivity.class);
                startActivity(intent);
            }
        });
        btnPhone = (Button) findViewById(R.id.button4);
        btnPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ShowLandMarkInfoActivity.this, CallPhone.class);
                intent.putExtra("PhoneNumber",etPhone.getText().toString());
                startActivity(intent);
            }
        });

        btnCard = (Button) findViewById(R.id.button5);
        btnCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setCard();
            }
        });

    }
    public void setCard()
    {
        if(0<=iIndex&&iIndex<ListLandMarkActivity.pLandMark.size())
        {
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(iIndex).split("-");
            if(arr[8].compareTo("false")==0)
            {
                ListLandMarkActivity.pLandMark.remove(iIndex);
                String str = arr[0]+"-"+arr[1]+"-"+arr[2]+"-"+arr[3]+"-"+arr[4]+"-"+arr[5]+"-"+arr[6]+"-"+arr[7]+"-true" +"-"+arr[9];
                etChe.setChecked(true);
                if(iIndex>=ListLandMarkActivity.pLandMark.size())
                    ListLandMarkActivity.pLandMark.add(str);
                else
                    ListLandMarkActivity.pLandMark.add(iIndex,str);
            }
        }
    }
    public void ShowLandMarkInfo(String name)
    {
        int images[] = {R.drawable.land1,R.drawable.land2,R.drawable.land3,R.drawable.land4,R.drawable.land5,R.drawable.land6,R.drawable.land7,R.drawable.land8};

        etName.setText("");
        etLocation.setText("");
        etAddress.setText("");
        etPhone.setText("");
        etOpentime.setText("");

        etDis = (EditText) findViewById(R.id.editText6);


        for (int i = 0; i < ListLandMarkActivity.pLandMark.size(); i++)
        {
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(i).split("-");
            if (arr[0].compareTo(name) == 0)
            {
                etName.setText(arr[0]);
                etLocation.setText(arr[1]);
                etAddress.setText(arr[2]);
                ivImage.setImageResource(images[i]);
                etPhone.setText(arr[4]);
                etOpentime.setText(arr[5]);
                etDis.setText("景點描述:\n"+arr[6]);
                sStyle = arr[7];
                etWeb.setText(arr[9]);
                iIndex=i;
            }
        }
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0)
        {
            if (resultCode == RESULT_OK)
            {
                String contents = data.getStringExtra("SCAN_RESULT");
                etScan.setText(contents);
            }
            if (resultCode == RESULT_CANCELED) {
                //handle cancel
            }
        }
    }

}