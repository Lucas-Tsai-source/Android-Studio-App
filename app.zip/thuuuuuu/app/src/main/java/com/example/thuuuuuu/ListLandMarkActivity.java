package com.example.thuuuuuu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Vector;

public class ListLandMarkActivity extends AppCompatActivity {


    ListView listview = null;
    public static Vector<String> pLandMark = null;
    Vector<String> pList = null;
    Button btnSearch = null;
    EditText etKeyword=null;

    ArrayAdapter adapter=null;
    static
    {
        pLandMark = new Vector<String>();
        pLandMark.add("路思義教堂-24.178840, 120.600364-台中市西屯區台灣大道四段1727號-land1.jpg-0423590121-不開放-莊嚴的路思義教堂-景點-false-https://www.thu.edu.tw");
        pLandMark.add("管理學院-24.182754, 120.612272-台中市西屯區台灣大道四段1727號-land2.jpg-0423590121-8:00~17:00-學生上課的管院大樓-學院-false-https://www.thu.edu.tw");
        pLandMark.add("管院711-24.183002, 120.611852-台中市西屯區台灣大道四段1727號-land3.jpg-0423590121-8:00~21:00-休閒的地方-商店-false-https://www.thu.edu.tw");
        pLandMark.add("東海男餐-24.181939, 120.601680-台中市西屯區台灣大道四段1727號-land4.jpg-0423590121-8:00~21:00-吃飯休息的地方-餐廳-false-https://www.thu.edu.tw");

        pLandMark.add("畢律斯鐘樓-24.178763, 120.601781-台中市西屯區台灣大道四段1727號-land5.jpg-0423590121-全時段開放-歷史悠久的鐘-景點-false-https://www.thu.edu.tw");
        pLandMark.add("東海圖書館-24.180071, 120.597010-台中市西屯區台灣大道四段1727號-land6.jpg-0423590121-8:00~21:00-安靜的圖書館-學院-false-https://www.thu.edu.tw");
        pLandMark.add("東海對味好食-24.178963, 120.612145-台中市西屯區台灣大道四段1727號-land7.jpg-0423590121-8:00~21:00-二校學生餐廳-餐廳-false-https://www.thu.edu.tw");
        pLandMark.add("東海花餐-24.180030, 120.601348-台中市西屯區台灣大道四段1727號-land8.jpg-0423590121-8:00~21:00-花圓餐廳-商店-false-https://www.thu.edu.tw");

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("景點列表");
        setContentView(R.layout.activity_list_land_mark);


        //Toast.makeText(ListLandMarkActivity.this, "你成功跳過來了", Toast.LENGTH_LONG).show();
        pList = new Vector<String>();


        btnSearch=(Button) findViewById(R.id.button1);

        etKeyword=(EditText) findViewById(R.id.editText1);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showGoods(etKeyword.getText().toString());
            }
        });

        listview = (ListView) findViewById(R.id.listView1);

        adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                pList);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListLandMarkActivity.this, ShowLandMarkInfoActivity.class);
                intent.putExtra("LandMark",(String)adapter.getItem(position));
                startActivity(intent);

            }
        });
        showGoods("");

    }
    public void showGoods(String keyword)
    {
        pList.clear();
        for(int i=0;i< pLandMark.size();i++)
        {
            String str =pLandMark.elementAt(i);
            String arr[]= str.split("-");
            if (str.indexOf(keyword)!=-1)
            {
                pList.add(arr[0]);
            }

        }
        adapter.notifyDataSetChanged();
    }

}