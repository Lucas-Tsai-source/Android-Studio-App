package com.example.thuuuuuu;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Intent;
import android.net.*;
import android.widget.Toast;

public class ShowGoodInfoActivity extends AppCompatActivity {

    EditText etISBN = null;
    EditText etName = null;
    EditText etPrice = null;
    EditText etQty = null;
    EditText etBuyInfo = null;
    EditText etDis = null;
    ImageView ivImage = null;
    Button btnScan = null;
    Button btnBuy = null;
    Button btnPerson = null;
    public static String sMyCart = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_good_info);

        etISBN = (EditText) findViewById(R.id.editText1);
        etName = (EditText) findViewById(R.id.editText2);
        etPrice = (EditText) findViewById(R.id.editText3);
        etQty = (EditText) findViewById(R.id.editText4);
        etDis = (EditText) findViewById(R.id.editText6);
        etBuyInfo = (EditText) findViewById(R.id.editText7);
        ivImage = (ImageView) findViewById(R.id.imageView1);

        String GoodName = this.getIntent().getStringExtra("GoodName");
        showGoodInfo(getISBN(GoodName));
        this.setTitle("商品資訊");
        btnScan = (Button) findViewById(R.id.button1);
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {

                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE"); // "PRODUCT_MODE for bar codes

                    startActivityForResult(intent, 0);

                } catch (Exception e) {

                    Uri marketUri = Uri.parse("market://details?id=com.google.zxing.client.android");
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    startActivity(marketIntent);

                }
            }
        });
        btnBuy = (Button) findViewById(R.id.button2);
        btnBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buyGood();
            }
        });
        btnPerson = (Button) findViewById(R.id.button3);
        btnPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(ShowGoodInfoActivity.this, ShowPersonDataActivity.class);
                startActivity(intent);
            }
        });
    }

    public void buyGood() {
        int sum = 0;
        if (etQty.length() == 0 || etQty.getText().toString().compareTo("0") == 0) {
            Toast.makeText(ShowGoodInfoActivity.this, "你沒輸入數量或數量不可為0", Toast.LENGTH_SHORT);
        } else {
            String buyinfo = "";
            buyinfo += "購物車內容:\n";
            for (int i = 0; i < ListGoodsActivity.pGoods.size(); i++) {
                String arr[] = ListGoodsActivity.pGoods.elementAt(i).split("-");
                if (arr[0].compareTo(etISBN.getText().toString()) == 0) {
                    ListGoodsActivity.pGoods.remove(i);
                    ListGoodsActivity.pGoods.add(i, arr[0] + "-" + arr[1] + "-" + arr[2] + "-" + arr[3] + "-" + etQty.getText().toString());
                }
                arr = ListGoodsActivity.pGoods.elementAt(i).split("-");
                int price = Integer.parseInt(arr[2]);
                int qty = Integer.parseInt(arr[4]);
                if (qty > 0) {
                    buyinfo += "你購買了" + arr[1] + ",價格是" + arr[2] + ",數量是" + arr[4] + ",總共是"+qty * price +"\n";
                    sum += qty * price;
                }
            }
            buyinfo +="總價是:" + sum+"";
            etBuyInfo.setText(buyinfo);
            sMyCart = etBuyInfo.getText().toString();
        }
    }

    public String getISBN(String name) {
        for (int i = 0; i < ListGoodsActivity.pGoods.size(); i++) {
            String arr[] = ListGoodsActivity.pGoods.elementAt(i).split("-");
            if (arr[1].compareTo(name) == 0)
                return arr[0];
        }
        return "";
    }


    public void showGoodInfo(String isbn) {
        int images[] = {R.drawable.good1,R.drawable.good2,R.drawable.good3,R.drawable.good4,R.drawable.good5,R.drawable.good6,R.drawable.good7,R.drawable.good8};
        etISBN = (EditText) findViewById(R.id.editText1);
        etName = (EditText) findViewById(R.id.editText2);
        etPrice = (EditText) findViewById(R.id.editText3);
        etQty = (EditText) findViewById(R.id.editText4);
        etDis = (EditText) findViewById(R.id.editText6);
        for (int i = 0; i < ListGoodsActivity.pGoods.size(); i++) {
            String arr[] = ListGoodsActivity.pGoods.elementAt(i).split("-");
            if (arr[0].compareTo(isbn) == 0) {
                etISBN.setText(arr[0]);
                etName.setText(arr[1]);
                etPrice.setText(arr[2]);
                etQty.setText(arr[4]);
                ivImage.setImageResource(images[i]);
                etDis.setText("商品描述:\n"+arr[5]);
            }
        }
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {

            if (resultCode == RESULT_OK) {
                String contents = data.getStringExtra("SCAN_RESULT");
                etISBN.setText(contents);
                showGoodInfo(contents);
            }
            if (resultCode == RESULT_CANCELED) {
                //handle cancel
            }
        }
    }
    public void save()
    {
        SharedPreferences pref = getSharedPreferences("MyData", MODE_PRIVATE);
        pref.edit()
                .putString("ISBN",etISBN.getText().toString())
                .putString("品名",etName.getText().toString())
                .putString("價格",etPrice.getText().toString())
                .putString("數量",etQty.getText().toString())
                .commit();
    }
}