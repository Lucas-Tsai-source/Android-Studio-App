package com.example.thuuuuuu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Button btnList = null;
    Button btnAbout= null;
    Button btnStore= null;
    ImageView ivImage = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewFlipper t = (ViewFlipper)findViewById(R.id.ViewFlipper1);
        int images[] = { R.drawable.good6,R.drawable.good2,R.drawable.good7,R.drawable.good8};
        for(int i=0 ; i<images.length;i++)
        {
            ImageView image = new ImageView(getApplicationContext());
            image.setBackgroundResource(images[i]);
            t.addView(image);
        }
        t.setFlipInterval(2000);
        t.startFlipping();

        this.setTitle("Thu app");
        btnList = (Button) findViewById(R.id.button1);

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "顯示一個訊息", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, ListLandMarkwithImageActivity.class);
                startActivity(intent);
            }
        });
        btnAbout = (Button) findViewById(R.id.button2);
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });
        btnStore = (Button) findViewById(R.id.button5);
        btnStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, ShowMapActivity.class);
                startActivity(intent);
            }
        });

    }
}