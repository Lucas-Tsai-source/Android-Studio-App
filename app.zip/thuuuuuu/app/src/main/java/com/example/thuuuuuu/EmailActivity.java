package com.example.thuuuuuu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.*;
import android.net.Uri;
import android.*;
import android.widget.Button;

public class EmailActivity extends AppCompatActivity {
    EditText ettxt = null;
    Button btnemail = null;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        this.setTitle("email");
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_email);
        ettxt = (EditText) findViewById(R.id.editText3);
        ettxt.setText(ShowGoodInfoActivity.sMyCart+"\n"+ShowPersonDataActivity.sMyData);

        btnemail = (Button) findViewById(R.id.button6);
        btnemail.setOnClickListener(new View.OnClickListener()
        {
            public void onClick (View view)
            {
                Intent email = new Intent(Intent.ACTION_SEND);
                email.setType("message/rfc822");
                email.putExtra(Intent.EXTRA_EMAIL, new String[]{"xxxxxxxx@gmail.com"});
                email.putExtra(Intent.EXTRA_SUBJECT, "訂單內容");
                email.putExtra(Intent.EXTRA_TEXT, ShowPersonDataActivity.sMyData+"\n"+ShowGoodInfoActivity.sMyCart);
                try {
                    startActivity(Intent.createChooser(email, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(EmailActivity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}