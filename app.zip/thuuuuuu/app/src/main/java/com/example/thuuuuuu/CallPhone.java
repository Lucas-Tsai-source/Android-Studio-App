package com.example.thuuuuuu;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.net.*;
import android.widget.EditText;
import android.telephony.*;
public class CallPhone extends AppCompatActivity {
    Button btnCallPhone = null;
    Button btnSendMessage = null;
    EditText etPhone = null;
    EditText etMsg = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_phone);
        etPhone = (EditText)findViewById(R.id.editText1);
        etPhone.setText("09xxxxxxxxx");
        this.setTitle("call phone");

        String phone=this.getIntent().getStringExtra("PhoneNumber");
        if(phone!=null)
        {
            etPhone.setText(phone);
        }

        btnCallPhone = (Button) findViewById(R.id.button1);
        btnCallPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+etPhone.getText().toString()));
                startActivity(intent);
            }
        });
        btnCallPhone = (Button) findViewById(R.id.button2);
        btnCallPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(etPhone.getText().toString() , null , etMsg.getText().toString() ,null ,null);
            }
        });
    }
}