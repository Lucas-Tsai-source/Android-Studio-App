package com.example.thuuuuuu;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.Vector;

public class ShowMapActivity extends AppCompatActivity {

    Spinner spinner1=null;
    Spinner spinner2=null;
    Spinner spinner3=null;
    Spinner spinner4=null;
    WebView pWeb=null;
    LocationManager mLocationManager = null;
    TextView tvGPSInfo = null;
    Location pLocation = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_map);

        Vector<String>pList = new Vector<String>();
        for (int i = 0; i < ListLandMarkActivity.pLandMark.size(); i++) {//字串分解，將名稱(arr[0])移到spinner
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(i).split("-");
            pList.add(arr[0]);
        }
        pList.add(0,"請選擇");
        spinner1 = findViewById(R.id.spinner1);
        ArrayAdapter adapter1=new ArrayAdapter(this
                ,android.R.layout.simple_dropdown_item_1line,pList);
        spinner1.setAdapter(adapter1);
        pLocation = openGPS();
        tvGPSInfo = (TextView) findViewById(R.id.textView1);
        showLocation ();

        String landmarkstyle[]={"全部","景點","學院","商店","餐廳"};
        spinner2= findViewById(R.id.spinner2);
        ArrayAdapter adapter2=new ArrayAdapter(this
                ,android.R.layout.simple_dropdown_item_1line,landmarkstyle);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadMap();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


        String zoomsize[]={"13","15","17","19"};
        spinner3= findViewById(R.id.spinner3);
        ArrayAdapter adapter3=new ArrayAdapter(this
                ,android.R.layout.simple_dropdown_item_1line,zoomsize);
        spinner3.setAdapter(adapter3);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadMap();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


        String mapstyle[]={"roadmap","hybrid","satellite","terrain"};
        spinner4= findViewById(R.id.spinner4);
        ArrayAdapter adapter4=new ArrayAdapter(this
                ,android.R.layout.simple_dropdown_item_1line,mapstyle);
        spinner4.setAdapter(adapter4);
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadMap();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


        pWeb=(WebView) findViewById(R.id.webView1);
        WebSettings webSettings=pWeb.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        pWeb.setWebViewClient(new WebViewClient());
        loadMap();
    }



    public void showLocation ()
    {//依據是否取到目前位置的資訊，決定顯示哪一種訊息
        if(pLocation != null)
        {
            tvGPSInfo.setText("緯度：" + pLocation.getLatitude() + "經度：" + pLocation.getLongitude());
        }
        else
            tvGPSInfo.setText("沒有提到GPS位置。");
    }

    public void loadMap()
    {
        Location location = openGPS();
        String loc = "24.178743, 120.600561";
        if(location != null)
        {
            loc = location.getLatitude() + ", "+location.getLongitude();
            Toast.makeText(ShowMapActivity.this,"緯度: "+location.getLatitude() + ", "+location.getLongitude(), Toast.LENGTH_LONG).show();
        }
         else
        {
            Toast.makeText(ShowMapActivity.this,"請崇spinner2 3 4更新GPS和地圖", Toast.LENGTH_LONG).show();
        }
        //"&zoom=18&size=640x640&maptype=roadmap&key=AIzaSyBrCFdwZn_b6CQOf5nRrRicOActLseGTyc"
        String URL="http://maps.google.com/maps/api/staticmap?center=25.03091,121.50437"+loc+
                "&zoom="+spinner3.getSelectedItem().toString()+
                "&size=640x640&maptype="+spinner4.getSelectedItem().toString()+"&key=AIzaSyBrCFdwZn_b6CQOf5nRrRicOActLseGTyc";
        for(int i = 0; i < ListLandMarkActivity.pLandMark.size();i++) {
            String arr[] = ListLandMarkActivity.pLandMark.elementAt(i).split("-");
            if (spinner2.getSelectedItem().toString().compareTo("全部") == 0 ||
                    spinner2.getSelectedItem().toString().compareTo(arr[7]) == 0) {
                String color = "color:orange";
                if (arr[8].compareTo("true") == 0)
                    color = "color:purple";
                else if (arr[7].compareTo("商店") == 0)
                    color = "color:green";
                else if (arr[7].compareTo("餐廳") == 0)
                    color = "color:blue";
                else if (arr[7].compareTo("學院") == 0)
                    color = "color:red";
                else if (arr[7].compareTo("景點") == 0)
                    color = "color:yellow";
                URL += "&markers=" + color + "|label:" + (i + 1) + "|" + arr[1];
            }
        }
        pWeb.loadUrl(URL);
    }
    //要手動開啟GPS服務，然後城市會帶出GPS管理者，進一步取得GPS資料
    public Location openGPS()
    {
        //取得GPS管理者
        mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        //設定GPS每隔多遠或每隔多久就更新一次，因為要設LocationListener，城市複雜，所以略過
        //mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, LOCATION, LOCATION_UPDATE_MIN_TIME * 1000)

        //設定GPS的相關參數
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_COARSE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(false);//設置允許產生資費
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        //GPS資訊來源有衛星和Wi-Fi，這裡決定用哪種來源
        String provider = mLocationManager.getBestProvider(criteria, false);
        try
        {//使用GPS是要用全縣，傳統是在AndriodMainfest.xml設定所有頁面的權限，新的方式是要在每個頁面各自設定
            if (ActivityCompat.checkSelfPermission(ShowMapActivity.this , Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            //&& ActivityCompat.checkSelPermission(this, Mainfest.permission.ACCESS_COARSE_LOCATION) != PackageManger
            {//網路上說要取得Mainfest.permission.ACCESS_FINE_LOCATIOSS_COAN和Mainfest.permission.ACCERSE_LOCATION兩個
                //但是只要取得Mainfest.permission.ACCESS_FINE_LOCATION(衛星GPS資訊)的權限就可以了
                //Mainfest.permission.ACCESS_COARSE_LOCATION(Wi-Fi資訊)的精準度較差，可以不用取得權限
                ActivityCompat.requestPermissions((ShowMapActivity)this, new String[]{
                        android.Manifest.permission.ACCESS_FINE_LOCATION}, 10);
            }
        }
        catch (Exception e)
        {//有意外狀況，發出警告訊號
            Toast.makeText(ShowMapActivity.this, "Error：" + e.toString(), Toast.LENGTH_LONG).show();
        }
        //傳回目前位置的資訊
        return mLocationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
    }
}