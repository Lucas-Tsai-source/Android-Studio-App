package com.example.thuuuuuu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.util.*;

public class ListGoodsActivity extends AppCompatActivity {
    ListView listview = null;
    public static Vector<String> pGoods = null;
    Vector<String> pList = null;
    Button btnSearch = null;
    EditText etKeyword=null;
    ArrayAdapter adapter=null;
    static
    {
        pGoods = new Vector<String>();
        pGoods.add("001-楊枝甘露-50-good1.jpg-0-夏天消暑，清涼解渴");
        pGoods.add("002-茉香柚茶-20-good2.jpg-0-淡淡茶香，甘甜好喝");
        pGoods.add("003-蜜茶-20-good3.jpg-0-清爽無負擔");
        pGoods.add("004-柚茶脆冰棒-50-good4.jpg-0-夏天冰鎮一下");
        pGoods.add("005-檸檬茶-20-good5.jpg-0-酸酸甜甜的很好喝喔");
        pGoods.add("006-豆奶-20-good6.jpg-0-蛋白質的補充來源");
        pGoods.add("007-伯爵奶茶-30-good7.jpg-0-濃厚的茶香味");
        pGoods.add("008-波蜜-30-good8.jpg-0-健康好選擇");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_goods);

        this.setTitle("商品清單");
        Toast.makeText(ListGoodsActivity.this, "你成功跳過來了", Toast.LENGTH_LONG).show();
        pList = new Vector<String>();


        btnSearch=(Button) findViewById(R.id.button1);
        etKeyword=(EditText) findViewById(R.id.editText1);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showGoods(etKeyword.getText().toString());
            }
        });

        listview = (ListView) findViewById(R.id.listView1);
        //ListView 要顯示的內容
        //String[] str = {"滿天星","紫藤花","桃花","百合花","薰衣草","山茶花","櫻花","向日葵"};
        //android.R.layout.simple_list_item_1 為內建樣式，還有其他樣式可自行研究
        adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                pList);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ListGoodsActivity.this, ShowGoodInfoActivity.class);
                intent.putExtra("GoodName",(String)adapter.getItem(position));
                startActivity(intent);
            }
        });
        showGoods("");

    }
    public void showGoods(String keyword)
    {
        pList.clear();
        for(int i=0;i< pGoods.size();i++)
        {
            String str =pGoods.elementAt(i);
            String arr[]= str.split("-");
            if (str.indexOf(keyword)!=-1)
                pList.add(arr[1]);
        }
        adapter.notifyDataSetChanged();
    }
}